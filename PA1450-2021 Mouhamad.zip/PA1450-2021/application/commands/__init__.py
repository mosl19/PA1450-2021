"""Package containing handlers for each CLI command."""

__package__ = "application.commands"
