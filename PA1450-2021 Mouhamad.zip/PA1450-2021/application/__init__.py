"""The main package of the application."""

__package__ = "application"
